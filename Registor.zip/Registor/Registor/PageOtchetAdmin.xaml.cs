﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Registor
{
    /// <summary>
    /// Логика взаимодействия для PageOtchetAdmin.xaml
    /// </summary>
    public partial class PageOtchetAdmin : Page
    {public MainWindow mainWindow;
        public PageOtchetAdmin()
        {
            InitializeComponent();
        }
        SqlConnection sqlConnection = new SqlConnection("server=ASUS;Trusted_Connection=Yes;DataBase=ArtShcool;");
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable db;
        private void clear()
        {
            tbId.Text = " ";
            tbFIO.Text = " ";
            tbBirth.Text = " ";
           
            tbDatePostup.Text = " ";
            tbGroup.Text = " ";
            tb1.Text = " ";
            tb2.Text = " ";
            tb3.Text = " ";

        }
        private void show()
        {
            da = new SqlDataAdapter("Select * From [dbo].[Otchet]", sqlConnection);
            db = new DataTable();
            da.Fill(db);
            mydataGrid.ItemsSource = db.DefaultView;
            tbId.Focus();
        }
        private void otc_Loaded(object sender, RoutedEventArgs e)
        {
            show();
        }
        private void Add_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("INSERT INTO [dbo].[Otchet] (id, FIO, DateBirth, Well, [Group], PaymentAmount, DatePayment, DedtAmount) Values (@id, @FIO, @DateBirth, @Well, @Group, @PaymentAmount, @DatePayment, @DedtAmount)", sqlConnection);
            cmd.Parameters.AddWithValue("@id", tbId.Text);
            cmd.Parameters.AddWithValue("@FIO", tbFIO.Text);
            cmd.Parameters.AddWithValue("@DateBirth", tbBirth.Text);
          
            cmd.Parameters.AddWithValue("@Well", tbDatePostup.Text);
            cmd.Parameters.AddWithValue("@Group", tbGroup.Text);
            cmd.Parameters.AddWithValue("@PaymentAmount", tb1.Text);
            cmd.Parameters.AddWithValue("@DatePayment", tb2.Text);
            cmd.Parameters.AddWithValue("@DedtAmount", tb3.Text);
            sqlConnection.Open();
            cmd.ExecuteNonQuery();
            sqlConnection.Close();
            MessageBox.Show("Данные успешно добавлены");
            show();
            clear();
        }


        private void Delet_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("Delete From [dbo].[Otchet] Where id=@id", sqlConnection);
            cmd.Parameters.AddWithValue("@id", tbId.Text);

            sqlConnection.Open();
            cmd.ExecuteNonQuery();
            sqlConnection.Close();
            MessageBox.Show("Данные успешно удалены");
            show();
            clear();
        }


        private void mydataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid dataGrid = (DataGrid)sender;
            DataRowView dataRowView = dataGrid.SelectedItem as DataRowView;
            if (dataRowView != null)
            {
                tbId.Text = dataRowView["id"].ToString();
                tbFIO.Text = dataRowView["FIO"].ToString();
                tbBirth.Text = dataRowView["DateBirth"].ToString();
              
                tbDatePostup.Text = dataRowView["Well"].ToString();
                tbGroup.Text = dataRowView["Group"].ToString();
                tb1.Text = dataRowView["PaymentAmount"].ToString();
                tb2.Text = dataRowView["DatePayment"].ToString();
                tb3.Text = dataRowView["DedtAmount"].ToString();
            }

        }
        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("Update [dbo].[Otchet] Set FIO=@FIO, DateBirth=@DateBirth, Well=@Well, [Group]=@Group, PaymentAmount=@PaymentAmount, DatePayment=@DatePayment, DedtAmount=@DedtAmount Where id=@id", sqlConnection);
            cmd.Parameters.AddWithValue("@id", tbId.Text);
            cmd.Parameters.AddWithValue("@FIO", tbFIO.Text);
            cmd.Parameters.AddWithValue("@DateBirth", tbBirth.Text);
           
            cmd.Parameters.AddWithValue("@Well", tbDatePostup.Text);
            cmd.Parameters.AddWithValue("@Group", tbGroup.Text);
            cmd.Parameters.AddWithValue("@PaymentAmount", tb1.Text);
            cmd.Parameters.AddWithValue("@DatePayment", tb2.Text);
            cmd.Parameters.AddWithValue("@DedtAmount", tb3.Text);
            sqlConnection.Open();
            cmd.ExecuteNonQuery();
            sqlConnection.Close();
            MessageBox.Show("Данные успешно изменены");
            show();
            clear();
        }

        
    }
}

