﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Registor
{
    /// <summary>
    /// Логика взаимодействия для WindowAdmin.xaml
    /// </summary>
    public partial class WindowAdmin : Window
    {
        public WindowAdmin()
        {
            InitializeComponent();
            OpenPage(pages.PageMenuAdmin);
        }
        public DataTable Select(string selectSQL) // функция подключения к базе данных и обработка запросов
        {
            DataTable dataTable = new DataTable("dataBase");                // создаём таблицу в приложении
                                                                            // подключаемся к базе данных
            SqlConnection sqlConnection = new SqlConnection("server=ASUS;Trusted_Connection=Yes;DataBase=ArtShcool;");
            sqlConnection.Open();                                           // открываем базу данных
            SqlCommand sqlCommand = sqlConnection.CreateCommand();          // создаём команду
            sqlCommand.CommandText = selectSQL;                             // присваиваем команде текст
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand); // создаём обработчик
            sqlDataAdapter.Fill(dataTable);                                 // возращаем таблицу с результатом
            return dataTable;
        }

        public enum pages
        {
            PageMenuAdmin
        }
        public void OpenPage(pages pages)
        {
            if (pages == pages.PageMenuAdmin)
            {
                Frame1.Navigate(new PageMenuAdmin(this));
            }
           
        }

        private void buttonOtch_Click(object sender, RoutedEventArgs e)
        {
            Frame1.Content = new PageOtchetAdmin();
        }

        private void buttonPya_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Выход из системы");
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }

        private void buttonOtch_Copy_Click(object sender, RoutedEventArgs e)
        {
            OpenPage(pages.PageMenuAdmin);
        }
    }
}
