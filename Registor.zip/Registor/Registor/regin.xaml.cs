﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Registor
{
    /// <summary>
    /// Логика взаимодействия для regin.xaml
    /// </summary>
    public partial class regin : Page
    { public MainWindow mainWindow;
        public regin(MainWindow _mainWindow)
        {
            InitializeComponent();
            mainWindow = _mainWindow;
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            mainWindow.OpenPage(MainWindow.pages.login);
        }

        private void reg_Click(object sender, RoutedEventArgs e)
        {
            if (textBox_login.Text.Length > 0) // проверяем логин
{
                if (password.Password.Length > 0) // проверяем пароль
	{
                    if (password_Copy.Password.Length > 0) // проверяем второй пароль
		{


                    }else MessageBox.Show("Повторите пароль");
                }else MessageBox.Show("Укажите пароль");
            }else MessageBox.Show("Укажите логин");


            if (password.Password.Length >= 6)
{
                bool en = true; // английская раскладка
                bool number = false; // цифра

                for (int i = 0; i < password.Password.Length; i++) // перебираем символы
                {
                    if (password.Password[i] >= 'А' && password.Password[i] <= 'Я') en = false; // если русская раскладка
                if (password.Password[i] >= '0' && password.Password[i] <= '9') number = true; // если цифры
               
            }

            if (!en)
                MessageBox.Show("Доступна только английская раскладка"); // выводим сообщение
            else if (!number)
                MessageBox.Show("Добавьте хотя бы одну цифру"); // выводим сообщение
            if (en && number) // проверяем соответствие
            {
            }
        } else MessageBox.Show("пароль слишком короткий, минимум 6 символов");
            
            if (password.Password == password_Copy.Password) // проверка на совпадение паролей
            {
                MessageBox.Show("Пользователь зарегистрирован");
            }
            else MessageBox.Show("Пароли не совподают");
        }

    }
}
