﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace Registor
{
    /// <summary>
    /// Логика взаимодействия для PageTeacher.xaml
    /// </summary>
    public partial class PageTeacher : Page
    {
        public WindowTeacher teacher;
        public PageTeacher(WindowTeacher _teacher)
        {
            InitializeComponent();
            teacher = _teacher;
        }

        SqlConnection sqlConnection = new SqlConnection("server=ASUS;Trusted_Connection=Yes;DataBase=ArtShcool;");
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable db;
       
        private void show()
        {
            da = new SqlDataAdapter("Select * From [dbo].[Otchet]", sqlConnection);
            db = new DataTable();
            da.Fill(db);
            mydataGrid.ItemsSource = db.DefaultView;
            
        }
        private void otc_Loaded(object sender, RoutedEventArgs e)
        {
            show();
        }
        private void mydataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid dataGrid = (DataGrid)sender;
            DataRowView dataRowView = dataGrid.SelectedItem as DataRowView;
          

        }
    }
}
